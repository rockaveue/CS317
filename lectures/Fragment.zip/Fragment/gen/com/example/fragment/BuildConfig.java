/** Automatically generated file. DO NOT MODIFY */
package com.example.fragment;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}